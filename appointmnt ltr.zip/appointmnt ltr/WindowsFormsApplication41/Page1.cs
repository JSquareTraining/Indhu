﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication41
{
    public partial class Page1 : Form
    {
        public Page1()
        {
            InitializeComponent();
        }
        Page2 f3 = new Page2();

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            label18.Text = string.Concat(label14.Text, label15.Text);
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            Page2 f3 = new Page2();
            f3.Show();
            f3.label15.Text = textBox1.Text;
            f3.label21.Text = textBox2.Text;
            f3.label19.Text = textBox3.Text;
            f3.label20.Text = textBox4.Text;
            f3.label11.Text = textBox4.Text;
            f3.label14.Text = textBox5.Text;
          
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.LemonChiffon;
            label2.Text = string.Format("{0:D}", DateTime.Now);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            
        }
    }
}
