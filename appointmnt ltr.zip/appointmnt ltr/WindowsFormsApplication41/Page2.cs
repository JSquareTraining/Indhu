﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication41
{
    public partial class Page2 : Form
    {
        public Page2()
        {
            InitializeComponent();
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            //if (textBox11.Text == "part time")
            //{
            //    textBox12.Text = "Not Eligible";
            //}
            //else if(textBox11.Text=="full time")
            //{
            //    textBox12.Text = "Eligible";
            //}
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            //if (textBox8.Text == "2,00,000")
            //{
            //    textBox9.Text = "(Two Lakh Only)";
            //}
            //else if (textBox8.Text == "3,00,000")
            //{
            //    textBox9.Text = "(Three Lakh Only)";
            //}
            //else if (textBox8.Text == "4,00,000")
            //{
            //    textBox9.Text = "(Four Lakh Only)";
            //}
            //else if (textBox8.Text == "5,00,000")
            //{
            //    textBox9.Text = "(Five Lakh Only)";
            //}
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {
            label20.Text = string.Copy(label11.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.LightBlue;
            label11.Text = string.Copy(label20.Text);
        }

        private void label11_Click(object sender, EventArgs e)
        {
            label11.Text = string.Copy(label19.Text);
        }
    }
}
