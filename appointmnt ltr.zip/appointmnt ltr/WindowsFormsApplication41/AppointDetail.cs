﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication41
{
    public partial class AppointDetail : Form
    {
        public AppointDetail()
        {
            InitializeComponent();
        }
        Page1 f2 = new Page1();
        Page2 f3 = new Page2();
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            f2.label4.Text = textBox3.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.LightCoral;
           
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            f2.label6.Text = textBox4.Text;
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {
            f2.label19.Text = textBox13.Text;
            f2.textBox1.Text = textBox13.Text;
            
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

            if (textBox8.Text == "2,00,000")
            {
                textBox9.Text = "(Two Lakh Only)";
            }
            else if (textBox8.Text == "3,00,000")
            {
                textBox9.Text = "(Three Lakh Only)";
            }
            else if (textBox8.Text == "4,00,000")
            {
                textBox9.Text = "(Four Lakh Only)";
            }
            else if (textBox8.Text == "5,00,000")
            {
                textBox9.Text = "(Five Lakh Only)";
            }
            f2.label23.Text = textBox8.Text;


        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            f2.label22.Text = textBox9.Text;

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {
            f2.label24.Text = textBox14.Text;
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            f2.label25.Text = textBox10.Text;
            f2.label26.Text = textBox10.Text;
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            if (textBox11.Text == "Part time")
            {
                textBox12.Text = "Not Eligible";
            }
            else if (textBox11.Text == "Full time")
            {
                textBox12.Text = "Eligible";
            }
            
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

           
        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {
            
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            f2.label8.Text = string.Concat(textBox1.Text, textBox2.Text);
            f2.textBox5.Text = string.Concat(textBox1.Text, textBox2.Text);
            f2.label20.Text = string.Concat(textBox5.Text, textBox6.Text);
            f2.label21.Text = textBox7.Text;
            f2.label5.Text = String.Concat(textBox1.Text, textBox2.Text);
            f2.textBox3.Text = textBox12.Text;
            f2.textBox4.Text = textBox15.Text;
            f2.textBox2.Text = textBox11.Text;
           
            f2.Show();
          
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
