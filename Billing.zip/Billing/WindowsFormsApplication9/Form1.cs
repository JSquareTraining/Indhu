﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {
        
  
       
        
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Billing System";
            this.BackColor = Color.Pink;
          
           
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            this.Text = "Billing Execution";
        }
       
      

        private void textBox8_Click(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(textBox6.Text);
            int j = Convert.ToInt32(textBox7.Text);
            int k1;
           
            
            k1 = i * j;
            textBox8.Text = Convert.ToString(k1);
           
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int q;
            if (textBox1.Text == "BAT")
            { q = 10;
            textBox2.Text = Convert.ToString(q);
            }
            else if (textBox1.Text == "BALL")
            {
                q = 20;
                textBox2.Text = Convert.ToString(q);
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            int q;
            if (textBox5.Text == "PEN")       
            {
                q = 20;
                textBox6.Text = Convert.ToString(q);
            }
            else if (textBox5.Text == "PAINT")
            {
                q = 30;
                textBox6.Text = Convert.ToString(q);
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(textBox2.Text);
            int j = Convert.ToInt32(textBox3.Text);
            int k;
            int t;
            int dis;
            int net;



            k = i * j;
            t = k;
            dis = ((t*10)/100);
            net = t - dis;
            textBox4.Text = Convert.ToString(k);
            textBox9.Text = Convert.ToString(t);
            textBox10.Text = Convert.ToString(dis);
            textBox11.Text = Convert.ToString(net);
            
           
        }

        private void label5_Click(object sender, EventArgs e)
        { }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            int t1 = Convert.ToInt32(textBox4.Text);
            int t2 = Convert.ToInt32(textBox8.Text);
            int t;
            int dis;
            int net;
            t = t1 + t2;
            dis = ((t * 20) / 100);
            net = t - dis;
            textBox9.Text = Convert.ToString(t);
            textBox10.Text = Convert.ToString(dis);
            textBox11.Text = Convert.ToString(net);
        }
        }

    }