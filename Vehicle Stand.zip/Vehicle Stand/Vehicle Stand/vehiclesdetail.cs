﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vehicle_Stand
{
    public partial class vehiclesdetail : Form
    {
        public vehiclesdetail()
        {
            InitializeComponent();
        }
        Properties.Settings ps = new Properties.Settings();
        bill f2 = new bill();
        private void button1_Click(object sender, EventArgs e)
        {
            textBox4.Text = DateTime.Now.ToString();

            //f2.dateTimePicker1.Value = DateTime.Now;
            ps.dat_tim = DateTime.Now;
            f2.dateTimePicker1.Value = ps.dat_tim;
            ps.Save();
            if ((ps.n1 == "")||(ps.n2=="")||(ps.n3=="")||(ps.n4=="")||(ps.n5==""))
            {
                if (ps.n1 == "")
                {
                    ps.n1 = textBox2.Text;
                }
                else if (ps.n2 == "")
                {
                    ps.n2 = textBox2.Text;
                }
                else if (ps.n3 == "")
                {
                    ps.n3 = textBox2.Text;
                }
                else if (ps.n4 == "")
                {
                    ps.n4 = textBox2.Text;
                }
                else if (ps.n5 == "")
                {
                    ps.n5 = textBox2.Text;
                }
            }

            if ((ps.m1 == "") || (ps.m2 == "") || (ps.m3 == "") || (ps.m4 == "") || (ps.m5 == ""))
            {
                if (ps.m1 == "")
                {
                    ps.m1 = textBox3.Text;
                }
                else if (ps.m2 == "")
                {
                    ps.m2 = textBox3.Text;
                }
                else if (ps.m3 == "")
                {
                    ps.m3 = textBox3.Text;
                }
                else if (ps.m4 == "")
                {
                    ps.m4 = textBox3.Text;
                }
                else if (ps.m5 == "")
                {
                    ps.m5 = textBox3.Text;
                }
            }
            
           
          
            if ((ps.v1 == "100") || (ps.v2 == "200") || (ps.v3 == "300") || (ps.v4 == "400") || (ps.v5 == "500"))
            {
                if (ps.v1 == "100")
                {
                    ps.v1 = textBox1.Text;
                    ps.m1 = textBox3.Text;
                    ps.n1 = textBox2.Text;
                    listBox1.Items.Add(ps.v1);
                 
                }
                else if (ps.v2 == "200")
                {
                    ps.v2 = textBox1.Text;
                    ps.m2 = textBox3.Text;
                    ps.n2 = textBox2.Text;
  
                    listBox1.Items.Add(ps.v2);
                 
                }
                else if (ps.v3 == "300")
                {
                    ps.v3 = textBox1.Text;
                    ps.m3 = textBox3.Text;
                    ps.n3 = textBox2.Text;
                    listBox1.Items.Add(ps.v3);
                 }
                else if (ps.v4 == "400")
                {
                    ps.v4 = textBox1.Text;
                    ps.m4 = textBox3.Text;
                    ps.n4 = textBox2.Text;
                    listBox1.Items.Add(ps.v4);
                }
                else if (ps.v5 == "500")
                {
                    ps.v5 = textBox1.Text;
                    ps.m5 = textBox3.Text;
                    ps.n5 = textBox2.Text;
                    listBox1.Items.Add(ps.v5);
                }
             }
           
           
            if (ps.v2 == ps.v1)
            {
                MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                ps.v2 = "200";
                int l = listBox1.Items.Count - 1;
                listBox1.Items.RemoveAt(l);
                ps.ch2 = "";
                ps.n2 = "";
                ps.m2 = "";

            }
            if (ps.v3 == ps.v1)
            {
                MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                ps.v3 = "300";
                int l = listBox1.Items.Count - 1;
                listBox1.Items.RemoveAt(l);
                ps.ch3 = "";
                ps.n3 = "";
                ps.m3 = "";
            }
            if (ps.v3 == ps.v2)
            {
                MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                ps.v3 = "300";
                int l = listBox1.Items.Count - 1;
                listBox1.Items.RemoveAt(l);
                ps.ch3 = "";
                ps.n3 = "";
                ps.m3 = "";
            }
                
             if (ps.v4 == ps.v1)
                {
                    MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                    ps.v4 = "400";
                    int l = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(l);
                    ps.ch4 = "";
                    ps.n4 = "";
                    ps.m4 = "";
                }
             if (ps.v4 == ps.v2)
             {
                 MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                 ps.v4 = "400";
                 int l = listBox1.Items.Count - 1;
                 listBox1.Items.RemoveAt(l);
                 ps.ch4 = "";
                 ps.n4 = "";
                 ps.m4 = "";
             }
             if (ps.v4 == ps.v3)
             {
                 MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                 ps.v4 = "400";
                 int l = listBox1.Items.Count - 1;
                 listBox1.Items.RemoveAt(l);
                 ps.ch4 = "";
                 ps.n4 = "";
                 ps.m4 = "";
             }
             if (ps.v5 == ps.v1)
             {
                 MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                 ps.v5 = "500";
                 int l = listBox1.Items.Count - 1;
                 listBox1.Items.RemoveAt(l);
                 ps.ch5 = "";
                 ps.n5 = "";
                 ps.m5 = "";
             }
             if (ps.v5 == ps.v2)
             {
                 MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                 ps.v5 = "500";
                 int l = listBox1.Items.Count - 1;
                 listBox1.Items.RemoveAt(l);
                 ps.ch5 = "";
                 ps.n5 = "";
                 ps.m5 = "";
             }

             if (ps.v5 == ps.v3)
             {
                 MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                 ps.v5 = "500";
                 int l = listBox1.Items.Count - 1;
                 listBox1.Items.RemoveAt(l);
                 ps.ch5 = "";
                 ps.n5 = "";
                 ps.m5 = "";
             }
             if (ps.v5 == ps.v4)
             {
                 MessageBox.Show("Dont Make Duplicate :This num already Parked ");
                 ps.v5 = "500";
                 int l = listBox1.Items.Count - 1;
                 listBox1.Items.RemoveAt(l);
                 ps.ch5 = "";
                 ps.n5 = "";
                 ps.m5 = "";
             }


           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ps.m1 = ""; ps.m2 = ""; ps.m3 = ""; ps.m4 = ""; ps.m5 = "";
            ps.n1 = ""; ps.n2 = ""; ps.n3 = ""; ps.n4 = ""; ps.n5 = "";
            ps.v1 = "100"; ps.v2 = "200"; ps.v3 = "300"; ps.v4 = "400"; ps.v5 = "500";
            ps.ch1 = ""; ps.ch2 = ""; ps.ch3 = ""; ps.ch4 = ""; ps.ch5 = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
          
            if (listBox1.Text == ps.v1)
            {

                f2.textBox1.Text = ps.v1;
                f2.textBox2.Text = ps.n1;
                f2.textBox3.Text = ps.m1;
                //f2.textBox4.Text = ps.ch2;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                listBox1.Items.Remove(ps.v1);
              ps.v1 = "100";
              ps.n2 = "";
              ps.m2 = "";
              ps.Save();
               
            }
            else if (listBox1.Text == ps.v2)
            {
                f2.textBox1.Text = ps.v2;
                f2.textBox2.Text = ps.n2;
                f2.textBox3.Text = ps.m2;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                //f2.textBox4.Text = ps.ch2;
                listBox1.Items.Remove(ps.v2);
                ps.n2 = "";
                ps.m2 = "";
                ps.v2 = "200";
            }
            else if (listBox1.Text == ps.v3)
            {
                f2.textBox1.Text = ps.v3;
                f2.textBox2.Text = ps.n3;
                f2.textBox3.Text = ps.m3;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                listBox1.Items.Remove(ps.v3);
                ps.v3 = "300";
                ps.n2 = "";
                ps.m2 = "";
            }
            else if (listBox1.Text == ps.v4)
            {
                f2.textBox1.Text = ps.v4;
                f2.textBox2.Text = ps.n4;
                f2.textBox3.Text = ps.m4;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                //f2.textBox4.Text = ps.ch4;
                listBox1.Items.Remove(ps.v4);
                ps.v4 = "400";
                ps.n2 = "";
                ps.m2 = "";
            }
            else if (listBox1.Text == ps.v5)
            {
                f2.textBox1.Text = ps.v5;
                f2.textBox2.Text = ps.n5;
                f2.textBox3.Text = ps.m5;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                //f2.textBox4.Text = ps.ch5;
                listBox1.Items.Remove(ps.v5);
                ps.v5 = "500";
                ps.n2 = "";
                ps.m2 = "";
            }
            f2.textBox4.Text = textBox4.Text;
            f2.ShowDialog();
          
        }
    }
}
