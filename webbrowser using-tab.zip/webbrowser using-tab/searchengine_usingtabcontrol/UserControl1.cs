﻿using System;
using System.Windows.Forms;
using System.IO;
namespace searchengine_usingtabcontrol
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(toolStripComboBox1.Text);
            TextWriter tw;
            tw = File.AppendText(@"D:\firefox\history\history.txt");
            tw.WriteLine(toolStripComboBox1.Text);
            tw.Dispose();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            TextReader tr;
            tr = File.OpenText(@"D:\firefox\history\history.txt");
            f2.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            f2.ShowDialog();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            TextWriter tw1;
            tw1 = File.AppendText(@"D:\firefox\bookmark\bookmark.txt");
            tw1.WriteLine(toolStripComboBox1.Text);
            tw1.Dispose();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            TextReader tr1;
            tr1 = File.OpenText(@"D:\firefox\bookmark\bookmark.txt");
            Form2 f2 = new Form2();
            f2.richTextBox1.Text = tr1.ReadToEnd();
            tr1.Dispose();
            f2.ShowDialog();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {

        }
    }
}
