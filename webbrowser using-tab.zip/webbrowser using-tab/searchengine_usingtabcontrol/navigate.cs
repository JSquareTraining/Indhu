﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace searchengine_usingtabcontrol
{
    public partial class navigate : Form
    {
        public navigate()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TabPage tb = new TabPage();
            tb.Text = "new tab";
            UserControl us = new UserControl();
            us.Controls.Add(userControl12);
            us.Width = 970;
            us.Height = 501;
            tb.Controls.Add(us);
            TabPage tb1 = new TabPage();
            tb1.Text = "+";
            tb.Click += new EventHandler(tabControl1_Click);
            tabControl1.Controls.Add(tb);
            tabControl1.Controls.Add(tb1);
            tabControl1.Controls.Remove(tabPage2);
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {

        }
    }
}
