﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace DigitalDiary
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (File.Exists(@"D:\DigitalDiary\" + textBox1.Text + @"\" + textBox1.Text + ".txt"))
            {

                //     FileInfo of = new FileInfo(@"D:\DigitalDiary\" +textBox1.Text+@"\"+ textBox1.Text + ".txt");
                TextReader tr;
                tr = File.OpenText(@"D:\DigitalDiary\" + textBox1.Text + @"\" + textBox1.Text + ".txt");
               
                if ((textBox1.Text == tr.ReadLine()) && (textBox2.Text == tr.ReadLine() == true))
                {
                    loading f4 = new loading();
                    f4.label1.Text = textBox1.Text;

                    MessageBox.Show("Log-In Success");

                    f4.ShowDialog();
                    this.Hide();
                   
                }
               
            }
             else
                {
                    MessageBox.Show("Verify UserName/Password");
                    textBox1.Text = "";
                    textBox2.Text = "";
                }

        }
        private void textBox6_Validating(object sender, CancelEventArgs e)
        {

        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            //int r = textBox1.Text.IndexOf('@');
            //string m = textBox1.Text.Remove(r);
            //if (File.Exists(@"D:\DigitalDiary\" + textBox1.Text + @"\" + m + ".txt"))
            //{

            //    FileInfo of = new FileInfo(@"D:\DigitalDiary\" +textBox1.Text+@"\"+ m + ".txt");
            //    TextReader tr;
            //    tr = File.OpenText(@"D:\DigitalDiary\" +textBox1.Text+@"\"+ m + ".txt");
            //    string s = tr.ReadToEnd();
            //    int i = s.LastIndexOf('.');
            //    textBox6.Text = s.Remove(i + 1);
            //    tr.Dispose();
            //}
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            //int r = textBox1.Text.IndexOf('@');
            //string m = textBox1.Text.Remove(r);
            //if (File.Exists(@"D:\DigitalDiary\" + textBox1.Text + @"\" + m + ".txt"))
            //{

            //    FileInfo of = new FileInfo(@"D:\DigitalDiary\" +textBox1.Text+@"\"+ m + ".txt");
            //    TextReader tr;
            //    tr = File.OpenText(@"D:\DigitalDiary\" +textBox1.Text+@"\"+ m + ".txt");
            //    string s = tr.ReadToEnd();
            //    int i = s.LastIndexOf('.');
            //    textBox7.Text = s.Substring(i + 1);
            //    tr.Dispose();
            //}
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            //this.WindowState = FormWindowState.Maximized;
        }
    }
}