﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
namespace DigitalDiary
{
    public partial class write : Form
    {
        public write()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            richTextBox1.BackColor = Color.White;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
       
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process.Start("calc");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Process.Start("mspaint");
        }

        private void label4_Click(object sender, EventArgs e)
        {
            TextWriter tw;
            tw = File.CreateText(@"D:\DigitalDiary1\" + label1.Text + ".txt");
            tw.WriteAsync(richTextBox1.Text);
            tw.Dispose();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
      
        }

        private void label7_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void newToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void openToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            openFileDialog1.ShowDialog();
            TextReader tr1;
            tr1 = File.OpenText(openFileDialog1.FileName);
            richTextBox1.Text = tr1.ReadToEnd();
            tr1.Dispose();
        }

        private void richTextBox1_KeyPress_1(object sender, KeyPressEventArgs e)
        {
          
        }

        private void saveToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            string i = monthCalendar1.SelectionStart.ToShortDateString();
            TextWriter tw;
            tw = File.CreateText(@"D:\DigitalDiary1\" + label1.Text + @"\"+i + ".txt");
            tw.WriteAsync(richTextBox1.Text);
            tw.Dispose();
        }

        private void lbl_read_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
       
        }

        private void monthCalendar1_DateChanged_1(object sender, DateRangeEventArgs e)
        {
           

        }

        private void lbl_write_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void lbl_new_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void lbl_copy_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void lbl_paste_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void lbl_undo_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void button4_Click(object sender, EventArgs e)
        {
        }

        private void monthCalendar1_Validating(object sender, CancelEventArgs e)
        {
       
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string s = monthCalendar1.SelectionStart.ToShortDateString();
            //string[] i = s.Split('/');
            //foreach (string d in i)
            //{
            //    MessageBox.Show(d);
            //}
            //int j = s.IndexOf("/");
            //int k = s.LastIndexOf("/");
            //string g = (s.Replace(j, -);//,s.Replace(k,"-");
            string m = s.Replace("/", "-");
            MessageBox.Show(m);
            if (File.Exists(@"D:\DigitalDiary\" + label1.Text + @"\" + m + ".txt") == true)
            {
               
                    TextWriter tw;
                    tw = File.AppendText(@"D:\DigitalDiary\" + label1.Text + @"\" + m + ".txt");
                    tw.WriteLine(richTextBox1.Text);
                    tw.Dispose();
               
            }
            else
            {
              
                    TextWriter tw1;
                    tw1 = File.CreateText(@"D:\DigitalDiary\" + label1.Text + @"\" + m + ".txt");
                    tw1.WriteLine(richTextBox1.Text);
                    tw1.Dispose();
               
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            button3.Enabled = true;
                richTextBox1.Text = "";
                richTextBox1.BackColor = Color.Turquoise;
               
         
                    
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            button3.Enabled = false;
            string s = monthCalendar1.SelectionStart.ToShortDateString();
            string m = s.Replace("/", "-");
            TextReader tr;
            tr = File.OpenText(@"D:\DigitalDiary\" + label1.Text + @"\" + m + ".txt");
            richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

       

        private void save_Click(object sender, EventArgs e)
        {
           
        }

        private void saveAs_Click(object sender, EventArgs e)
        {
           
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
            pasteToolStripMenuItem.Enabled = true;
        }

        private void copy_Click(object sender, EventArgs e)
        {

            richTextBox1.Copy();
            pasteToolStripMenuItem.Enabled = true;
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text.Remove(richTextBox1.SelectionStart, richTextBox1.SelectionLength);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cutToolStripMenuItem.Enabled = true;
            copy.Enabled = true;
            deleteToolStripMenuItem.Enabled = richTextBox1.SelectionLength > 0;
            if (richTextBox1.Text == "")
            {
                findNextToolStripMenuItem.Enabled = false;
                findToolStripMenuItem.Enabled = false;
                undoToolStripMenuItem.Enabled = false;
            }
            else if (richTextBox1.Text != "")
            {
                findNextToolStripMenuItem.Enabled = true;
                findToolStripMenuItem.Enabled = true;
                undoToolStripMenuItem.Enabled = true;
            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {

            fontDialog1.ShowDialog();
            richTextBox1.Font = fontDialog1.Font;
        }

        private void statusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void open_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            openFileDialog1.ShowDialog();
            TextReader tr1;
            tr1 = File.OpenText(openFileDialog1.FileName);
            richTextBox1.Text = tr1.ReadToEnd();
            tr1.Dispose();
        }

     

        //private void toolStripMenuItem4_Click(object sender, EventArgs e)
        //{

        //}

      
      
    }
}
