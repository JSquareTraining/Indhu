﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalDiary
{
    public partial class loading : Form
    {
        public loading()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Text = DateTime.Now.ToLongTimeString();
            if (progressBar1.Value < 1000)
            {
                progressBar1.Value += 10;


            }
            else
            {
                timer1.Stop();
                write f5 = new write();
                f5.label1.Text = label1.Text;
                f5.ShowDialog();
                this.Hide();
            }
            
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
