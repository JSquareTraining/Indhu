﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace DigitalDiary
{
    public partial class regform : Form
    {
        public regform()
        {
            InitializeComponent();
        }


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(@"D:\DigitalDiary\" + txt_name.Text);
            if (File.Exists(@"D:\DigitalDiary\" +txt_name.Text+@"\"+ txt_name.Text + ".txt"))
            {
                MessageBox.Show("File Exist");
                txt_name.Text = "";
                txt_passwrd.Text = "";
                //if (txt_passwrdconf.Text.Contains(txt_passwrd.Text) == false)
                //{
                //    MessageBox.Show("Password Mismatch");
                //}
                //if (txt_verify1.Text.Contains(txt_verify.Text) == false)
                //{
                //    MessageBox.Show("Enter correct Verification Code");
                //}
            }
            
                 
         
            else
            {
                TextWriter tw;
                tw = File.CreateText(@"D:\DigitalDiary\" +txt_name.Text+@"\"+ txt_name.Text + ".txt");
                tw.WriteLine(txt_name.Text);
                tw.WriteLine(txt_passwrd.Text);
                tw.Dispose();
                MessageBox.Show("Log-In Successfull");
                Form3 f3 = new Form3();
                f3.ShowDialog();
                this.Hide();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            txt_verify.Visible = false;
            txt_verify1.Visible = false;
        }

        private void cb_1_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_1.Checked == true)
            {
                txt_verify.Visible = true;
                txt_verify1.Visible = true;
            }
        }
    }
}
