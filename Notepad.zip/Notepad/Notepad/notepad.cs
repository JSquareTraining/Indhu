﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Notepad
{
    public partial class notepad : Form
    {
        public notepad()
        {
            InitializeComponent();
        }
        int open;
        Properties.Settings ps = new Properties.Settings();
        private void wordWrapToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
            if (ps.click == 0)
            {
                wordWrapToolStripMenuItem.Checked = true;
                if (wordWrapToolStripMenuItem.Checked == true)
                {
                    richTextBox1.Multiline = true;
                    statusBarToolStripMenuItem.Visible = false;
                    statusStrip1.Visible = false;
                    ps.click = 1;
                    ps.Save();
                }

            }
            else if (ps.click == 1)
            {
                wordWrapToolStripMenuItem.Checked = false;
                if (wordWrapToolStripMenuItem.Checked == false)
                {
                    richTextBox1.Multiline = false;
                    statusBarToolStripMenuItem.Visible = true;
                    statusStrip1.Visible = true;
                    ps.click = 0;
                    ps.Save();
                }

            }
        }
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (open != 1)
            {
                richTextBox1.Text = "";
                this.Text = "Untitled-Notepad";
            }
            if (richTextBox1.Text == "")
            {
                this.Text = "Untitled-Notepad";
            }
            else if (open == 1)
            {
                DialogResult dr = new DialogResult();
                dr = MessageBox.Show("Do you want to save changes to Untitled?", "Notepad", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                {
                    saveFileDialog1.Filter = ("textfiles(*.txt)|*.txt|allfiles(*.*)|*.*");
                    saveFileDialog1.ShowDialog();
                    TextWriter tw1;
                    tw1 = File.CreateText(saveFileDialog1.FileName);
                    tw1.WriteLine(richTextBox1.Text);
                    tw1.Dispose();
                    richTextBox1.Text = "";
                }
                else if (dr == DialogResult.No)
                {
                    richTextBox1.Text = "";
                    this.Text = "Untitled-Notepad";
                }

                else if (dr == DialogResult.Cancel)
                {

                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((richTextBox1.Text == "") && (open != 1))
            {
                openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                openFileDialog1.ShowDialog();
                TextReader tr1;
                tr1 = File.OpenText(openFileDialog1.FileName);
                richTextBox1.Text = tr1.ReadToEnd();
                tr1.Dispose();
                FileInfo f = new FileInfo(openFileDialog1.FileName);
                string s = f.Name;
                int i = s.IndexOf('.');
                string j = s.Remove(i);
                this.Text = j + "-Notepad";

            }
            else if (open == 1)
            {
                DialogResult dr = new DialogResult();
                dr = MessageBox.Show("Do you want to save changes to Untitled?", "Notepad", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                {
                    saveFileDialog1.Title = "Save";
                    saveFileDialog1.Filter = "textfiles(*.txt)|*.txt|All files(*.*)|*.*";
                    saveFileDialog1.ShowDialog();
                    TextWriter tw1;
                    tw1 = File.CreateText(saveFileDialog1.FileName);
                    textBox3.Text = saveFileDialog1.FileName.Substring(3);
                    int i = textBox3.Text.IndexOf('.');
                    textBox5.Text = textBox3.Text.Remove(i);
                    tw1.WriteLine(richTextBox1.Text);
                    DirectoryInfo d = new DirectoryInfo(@"D:\" + textBox3.Text);
                    string j = d.Name;
                    int l = j.IndexOf('.');
                    string m = j.Remove(l);
                    this.Text = m + "-Notepad";
                    tw1.Dispose();
                    openFileDialog1.Title = "Open";
                    openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                    openFileDialog1.ShowDialog();
                    TextReader tr1;
                    tr1 = File.OpenText(openFileDialog1.FileName);
                    richTextBox1.Text = tr1.ReadToEnd();
                    tr1.Dispose();
                    FileInfo f = new FileInfo(openFileDialog1.FileName);
                    string s = f.Name;
                    int x = s.IndexOf('.');
                    string y = s.Remove(x);
                    this.Text = y + "-Notepad";
                }
                else if (dr == DialogResult.No)
                {
                    openFileDialog1.Title = "Open";
                    openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                    openFileDialog1.ShowDialog();
                    TextReader tr1;
                    tr1 = File.OpenText(openFileDialog1.FileName);
                    richTextBox1.Text = tr1.ReadToEnd();
                    tr1.Dispose();
                    FileInfo f = new FileInfo(openFileDialog1.FileName);
                    string s = f.Name;
                    int x = s.IndexOf('.');
                    string y = s.Remove(x);
                    this.Text = y + "-Notepad";
                }

                else if (dr == DialogResult.Cancel)
                {

                }
            }
            else if (open != 1)
            {
                openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                openFileDialog1.ShowDialog();
                TextReader tr1;
                tr1 = File.OpenText(openFileDialog1.FileName);
                richTextBox1.Text = tr1.ReadToEnd();
                tr1.Dispose();
                FileInfo f = new FileInfo(openFileDialog1.FileName);
                string s = f.Name;
                int i = s.IndexOf('.');
                string j = s.Remove(i);
                this.Text = j + "-Notepad";

            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            richTextBox1.Font = fontDialog1.Font;
        }

        private void timeDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = DateTime.Now.ToString();
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
            pasteToolStripMenuItem.Enabled = true;
        }



        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text.Remove(richTextBox1.SelectionStart, richTextBox1.SelectionLength);
        }

        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            groupBox2.Visible = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (open != 1)
            {
                saveFileDialog1.Title = "Save As";
                saveFileDialog1.Filter = "textfiles(*.txt)|*.txt|All files(*.*)|*.*";
                saveFileDialog1.ShowDialog();
                TextWriter tw1;
                tw1 = File.CreateText(saveFileDialog1.FileName);
                textBox3.Text = saveFileDialog1.FileName.Substring(3);
                int i = textBox3.Text.IndexOf('.');
                textBox5.Text = textBox3.Text.Remove(i);
                tw1.WriteLine(richTextBox1.Text);
                DirectoryInfo d = new DirectoryInfo(@"D:\" + textBox3.Text);
                string j = d.Name;
                int l = j.IndexOf('.');
                string m = j.Remove(l);
                this.Text = m + "-Notepad";
                tw1.WriteLine(richTextBox1.Text);
                tw1.Dispose();
              
            }
            else if (open == 1)
            {
                saveFileDialog1.Title = "Save As";
                saveFileDialog1.Filter = "textfiles(*.txt)|*.txt|All files(*.*)|*.*";
                saveFileDialog1.ShowDialog();
                TextWriter tw2;
                tw2 = File.CreateText(saveFileDialog1.FileName);
                textBox3.Text = saveFileDialog1.FileName.Substring(3);
                int i = textBox3.Text.IndexOf('.');
                textBox5.Text = textBox3.Text.Remove(i);
                tw2.WriteLine(richTextBox1.Text);
                DirectoryInfo d = new DirectoryInfo(@"D:\" + textBox3.Text);
                string j = d.Name;
                int l = j.IndexOf('.');
                string m = j.Remove(l);
                this.Text = m + "-Notepad";
                tw2.WriteLine(richTextBox1.Text);
                tw2.Dispose();
            }
        }

        private void richTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            open = 1;
        }


        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            ps.click = 0;
            ps.status = 0;
          
        }

      

        private void richTextBox1_SelectionChanged(object sender, EventArgs e)
        {

        }

        private void cutToolStripMenuItem_TextChanged(object sender, EventArgs e)
        {

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.Text == "Untitled-Notepad")
            {
                saveFileDialog1.Title = "Save";
                saveFileDialog1.Filter = "textfiles(*.txt)|*.txt|All files(*.*)|*.*";
                saveFileDialog1.ShowDialog();
                TextWriter tw1;
                tw1 = File.CreateText(saveFileDialog1.FileName);
                textBox3.Text = saveFileDialog1.FileName.Substring(3);
                int i = textBox3.Text.IndexOf('.');
                textBox5.Text = textBox3.Text.Remove(i);
                tw1.WriteLine(richTextBox1.Text);
                DirectoryInfo d = new DirectoryInfo(@"D:\" + textBox3.Text);
                string j = d.Name;
                int l = j.IndexOf('.');
                string m = j.Remove(l);
                this.Text = m + "-Notepad";
                tw1.Dispose();

            }
            else if (this.Text != "Untitled-Notepad")
            {

                TextWriter tw;
                tw = File.CreateText(@"D:\" + textBox3.Text);
                tw.WriteLine(richTextBox1.Text);
                tw.Dispose();
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_TextChanged(object sender, EventArgs e)
        {

        }

        private void cutToolStripMenuItem_EnabledChanged(object sender, EventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {


            cutToolStripMenuItem.Enabled = true;
            copy.Enabled = true;
            deleteToolStripMenuItem.Enabled = richTextBox1.SelectionLength > 0;
            if (richTextBox1.Text == "")
            {
                findNextToolStripMenuItem.Enabled = false;
                findToolStripMenuItem.Enabled = false;
                undoToolStripMenuItem.Enabled = false;
            }
            else if (richTextBox1.Text != "")
            {
                findNextToolStripMenuItem.Enabled = true;
                findToolStripMenuItem.Enabled = true;
                undoToolStripMenuItem.Enabled = true;
            }
        }

        private void copy_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
            pasteToolStripMenuItem.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
        //int start = 0;
        //int indexOfSearchText = 0;
      
        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            //int startindex = 0;
            //if (textBox1.Text.Length > 0)
            //    //          startindex = FindMyText(textBox1.Text.Trim(), start, richTextBox1.Text.Length);
            //    startindex =(textBox1.Text.Trim(), start, richTextBox1.Text.Length);
            //if (startindex >= 0)
            //{
            //    richTextBox1.SelectionColor = Color.Blue;
            //    int endindex = textBox1.Text.Length;
            //    richTextBox1.Select(startindex, endindex);
            //    start=startindex+endindex;
            //}
           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            String s = richTextBox1.Text;
            //int j = s.LastIndexOf(textBox4.Text);
            //string l = j.ToString();
            int i = textBox1.Text.Length;
            if (s.Contains(textBox4.Text))
            {
                richTextBox1.Select(richTextBox1.Text.LastIndexOf(textBox4.Text), textBox4.Text.Length);
                richTextBox1.SelectionBackColor = Color.Blue;
                i--;
            }
            else
            {
                MessageBox.Show("cannot find "+ textBox4.Text);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
          

        }

        private void formatToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void wordWrapToolStripMenuItem_CheckStateChanged(object sender, EventArgs e)
        {
            if (wordWrapToolStripMenuItem.Checked == true)
            {
                richTextBox1.Multiline = true;
            }
            else
            {
                richTextBox1.Multiline = false;
            }
        }

        private void wordWrapToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void wordWrapToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void statusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Properties.Settings ps = new Properties.Settings();
            if (ps.status == 0)
            {
                statusBarToolStripMenuItem.Checked = true;
                if (statusBarToolStripMenuItem.Checked == true)
                {
                    
                    statusStrip1.Visible = true;
                    ps.status = 1;
                    ps.Save();
                }

            }
            else if (ps.status == 1)
            {
                statusBarToolStripMenuItem.Checked = false;
                if (statusBarToolStripMenuItem.Checked == false)
                {

                    statusStrip1.Visible = false;
                    ps.status = 0;
                    ps.Save();
                }

            }
        }
        
        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {

            
       }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
          
        }
    }
}