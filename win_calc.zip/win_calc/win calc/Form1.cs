﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string op1;
        string k1;
        string k2;
        string k3;
        calc cc = new calc();
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button1.Text;
            }
            else
            {
                textBox1.Text += button1.Text;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button2.Text;
            }
            else
            {
                textBox1.Text += button2.Text;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button3.Text;
            }
            else
            {
                textBox1.Text += button3.Text;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button4.Text;
            }
            else
            {
                textBox1.Text += button4.Text;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button5.Text;
            }
            else
            {
                textBox1.Text += button5.Text;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button6.Text;
            }
            else
            {
                textBox1.Text += button6.Text;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button7.Text;
            }
            else
            {
                textBox1.Text += button7.Text;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button8.Text;
            }
            else
            {
                textBox1.Text += button8.Text;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button9.Text;
            }
            else
            {
                textBox1.Text += button9.Text;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text += "+";
                string[] k = textBox1.Text.Split('+');
                k1 = string.Format("{0}", k);
                k2 = "+";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
            else
            {
                textBox1.Text += "+";
                string[] k = textBox1.Text.Split('+');
                k1 = string.Format("{0}", k); ;
                k2 = "+";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
            {
                textBox1.Text += "-";
                string[] k = textBox1.Text.Split('-');
                k1 = string.Format("{0}", k);
                k2 = "-";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
            else
            {
                textBox1.Text += "-";
                string[] k = textBox1.Text.Split('-');
                k1 = string.Format("{0}", k); ;
                k2 = "-";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text += "*";
                string[] k = textBox1.Text.Split('*');
                k1 = string.Format("{0}", k);
                k2 = "*";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
            else
            {
                textBox1.Text += "*";
                string[] k = textBox1.Text.Split('*');
                k1 = string.Format("{0}", k); ;
                k2 = "*";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text += "/";
                string[] k = textBox1.Text.Split('/');
                k1 = string.Format("{0}", k);
                k2 = "/";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
            else
            {
                textBox1.Text += "/";
                string[] k = textBox1.Text.Split('/');
                k1 = string.Format("{0}", k); ;
                k2 = "/";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (k2 == "+")
            {
                string[] k = textBox1.Text.Split('+');
                k1 = string.Format("{0}", k);
                k2 = "+";
                k3 = string.Format("{1}", k);
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                textBox1.Text = Convert.ToString(cc.opr(op1));
                cc.num1 = Convert.ToDouble(textBox1.Text);
            }
            else if(k2=="-")
            {
                string[] k = textBox1.Text.Split('-');
                k1 = string.Format("{0}", k);
                k2 = "-";
                k3 = string.Format("{1}", k);
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                textBox1.Text = Convert.ToString(cc.opr(op1));
                cc.num1 = Convert.ToDouble(textBox1.Text);
            }
            else if (k2 == "/")
            {
                string[] k = textBox1.Text.Split('/');
                k1 = string.Format("{0}", k);
                k2 = "/";
                k3 = string.Format("{1}", k);
                if (k1 == "0")
                {
                    textBox1.Text = Convert.ToString("Error");
                }
                else if (k3 == "0")
                {
                    textBox1.Text = "0";
                    cc.num1 = Convert.ToDouble(textBox1.Text);
                }
                else
                {
                    cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                    cc.opr(k2);
                    op1 = k2;
                    textBox1.Text = Convert.ToString(cc.opr(op1));
                    cc.num1 = Convert.ToDouble(textBox1.Text);
                }
            }
            else if (k2 == "*")
            {
                string[] k = textBox1.Text.Split('*');
                k1 = string.Format("{0}", k);
                k2 = "*";
                k3 = string.Format("{1}", k);
                if (k3 != "0")
                {
                    cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                    cc.opr(k2);
                    op1 = k2;
                    textBox1.Text = Convert.ToString(cc.opr(op1));
                    cc.num1 = Convert.ToDouble(textBox1.Text);
                }
                else
                {
                    textBox1.Text = "0";
                    cc.num1 = Convert.ToDouble(textBox1.Text);
                }
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text += button15.Text;
            }
            else
            {
                textBox1.Text += button15.Text;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = button10.Text;
            }
            else
            {
                textBox1.Text += button10.Text;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }
    }
}
