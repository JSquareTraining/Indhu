﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication48
{
    public partial class Tree : Form
    {
        public Tree()
        {
            InitializeComponent();
        }
        Properties.Settings ps = new Properties.Settings();
        private void button1_Click(object sender, EventArgs e)
        {
            if ((ps.name == "")&&(comboBox1.Enabled==false))
            {
                listBox1.Items.Add(textBox1.Text);
                ps.name = textBox1.Text;
                comboBox1.Enabled = true;
            }
           
            if ((comboBox1.Text == "0")&&(comboBox1.Enabled==true))
            {

                if ((ps.name1 == "") || (ps.name2 == "") || (ps.name3 == ""))
                {
                    if (ps.name1 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name1 = textBox1.Text;
                    }
                    else if (ps.name2 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name2 = textBox1.Text;
                    }
                    else if (ps.name3 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name3 = textBox1.Text;
                    }
                   
                }
                else
                {
                    MessageBox.Show("Choose Next ID");
                    
                }
                

            }

            if (comboBox1.Text == "1")
            {

                if ((ps.name4 == "") || (ps.name5 == "") || (ps.name6 == ""))
                {
                    if (ps.name4 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name4 = textBox1.Text;
                    }
                    else if (ps.name5 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name5 = textBox1.Text;
                    }
                    else if (ps.name6 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name6 = textBox1.Text;
                    }

                }
                else
                {
                    MessageBox.Show("Choose Next ID");
                }
            }
            if (comboBox1.Text == "2")
            {

                if ((ps.name7 == "") || (ps.name8 == "") || (ps.name9 == ""))
                {
                    if (ps.name7 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name7 = textBox1.Text;
                    }
                    else if (ps.name8 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name8 = textBox1.Text;
                    }
                    else if (ps.name9 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name9 = textBox1.Text;
                    }

                }
                else
                {
                    MessageBox.Show("Choose Next ID");
                }
            }
            if (comboBox1.Text == "3")
            {

                if ((ps.name10 == "") || (ps.name11 == "") || (ps.name12 == ""))
                {
                    if (ps.name10 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name10 = textBox1.Text;
                    }
                    else if (ps.name11 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name11 = textBox1.Text;
                    }
                    else if (ps.name12 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name12 = textBox1.Text;
                    }

                }
                else
                {
                    MessageBox.Show("Choose Next ID");
                }
            }
            if (comboBox1.Text == "4")
            {

                if ((ps.name13 == "") || (ps.name14 == "") || (ps.name15 == ""))
                {
                    if (ps.name13 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name13 = textBox1.Text;
                    }
                    else if (ps.name14 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name14 = textBox1.Text;
                    }
                    else if (ps.name15 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name15 = textBox1.Text;
                    }

                }
                else
                {
                    MessageBox.Show("Choose Next ID");
                }
            }
            if (comboBox1.Text == "5")
            {

                if ((ps.name16 == "") || (ps.name17 == "") || (ps.name18 == ""))
                {
                    if (ps.name16 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name16 = textBox1.Text;
                    }
                    else if (ps.name17 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name17 = textBox1.Text;
                    }
                    else if (ps.name18 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name18 = textBox1.Text;
                    }

                }
                else
                {
                    MessageBox.Show("Choose Next ID");
                }
            }
            if (comboBox1.Text == "6")
            {

                if ((ps.name19 == "") || (ps.name20 == "") || (ps.name21 == ""))
                {
                    if (ps.name19 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name19 = textBox1.Text;
                    }
                    else if (ps.name20 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name20 = textBox1.Text;
                    }
                    else if (ps.name21 == "")
                    {
                        listBox1.Items.Add(textBox1.Text);
                        ps.name21 = textBox1.Text;
                    }

                }
                else
                {
                    MessageBox.Show("Choose Next ID");
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ps.name = "";
            ps.name1 = "";
            ps.name2 = "";
            ps.name3 = "";
            ps.name4 = "";
            ps.name5 = "";
            ps.name6 = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.Text==ps.name)
            {
              
                listBox2.Items.Add(ps.name1);
                listBox2.Items.Add(ps.name2);
                listBox2.Items.Add(ps.name3);

            }

            else if (listBox1.Text == ps.name1)
            {
                listBox2.Items.Remove(ps.name1);
                listBox2.Items.Remove(ps.name2);
                listBox2.Items.Remove(ps.name3);
                listBox2.Items.Add(ps.name4);
                listBox2.Items.Add(ps.name5);
                listBox2.Items.Add(ps.name6);
               
            }

            else if (listBox1.Text == ps.name2)
            {

                listBox2.Items.Remove(ps.name1);
                listBox2.Items.Remove(ps.name2);
                listBox2.Items.Remove(ps.name3);
                listBox2.Items.Remove(ps.name4);
                listBox2.Items.Remove(ps.name5);
                listBox2.Items.Remove(ps.name6);
                listBox2.Items.Add(ps.name7);
                listBox2.Items.Add(ps.name8);
                listBox2.Items.Add(ps.name9);
              
            }

            else if (listBox1.Text == ps.name3)
            {

                listBox2.Items.Remove(ps.name1);
                listBox2.Items.Remove(ps.name2);
                listBox2.Items.Remove(ps.name3);
                listBox2.Items.Remove(ps.name4);
                listBox2.Items.Remove(ps.name5);
                listBox2.Items.Remove(ps.name6);
                listBox2.Items.Remove(ps.name7);
                listBox2.Items.Remove(ps.name8);
                listBox2.Items.Remove(ps.name9);
                listBox2.Items.Add(ps.name10);
                listBox2.Items.Add(ps.name11);
                listBox2.Items.Add(ps.name12);
               
            }
           
            else if (listBox1.Text == ps.name4)
            {

                listBox2.Items.Remove(ps.name1);
                listBox2.Items.Remove(ps.name2);
                listBox2.Items.Remove(ps.name3);
                listBox2.Items.Remove(ps.name4);
                listBox2.Items.Remove(ps.name5);
                listBox2.Items.Remove(ps.name6);
                listBox2.Items.Remove(ps.name7);
                listBox2.Items.Remove(ps.name8);
                listBox2.Items.Remove(ps.name9);
                listBox2.Items.Remove(ps.name10);
                listBox2.Items.Remove(ps.name11);
                listBox2.Items.Remove(ps.name12);
                listBox2.Items.Add(ps.name13);
                listBox2.Items.Add(ps.name14);
                listBox2.Items.Add(ps.name15);

            }
            else if (listBox1.Text == ps.name5)
            {

                listBox2.Items.Remove(ps.name1);
                listBox2.Items.Remove(ps.name2);
                listBox2.Items.Remove(ps.name3);
                listBox2.Items.Remove(ps.name4);
                listBox2.Items.Remove(ps.name5);
                listBox2.Items.Remove(ps.name6);
                listBox2.Items.Remove(ps.name7);
                listBox2.Items.Remove(ps.name8);
                listBox2.Items.Remove(ps.name9);
                listBox2.Items.Remove(ps.name10);
                listBox2.Items.Remove(ps.name11);
                listBox2.Items.Remove(ps.name12);
                listBox2.Items.Remove(ps.name13);
                listBox2.Items.Remove(ps.name14);
                listBox2.Items.Remove(ps.name15);
                listBox2.Items.Add(ps.name16);
                listBox2.Items.Add(ps.name17);
                listBox2.Items.Add(ps.name18);

            }

            else if (listBox1.Text == ps.name6)
            {

                listBox2.Items.Remove(ps.name1);
                listBox2.Items.Remove(ps.name2);
                listBox2.Items.Remove(ps.name3);
                listBox2.Items.Remove(ps.name4);
                listBox2.Items.Remove(ps.name5);
                listBox2.Items.Remove(ps.name6);
                listBox2.Items.Remove(ps.name7);
                listBox2.Items.Remove(ps.name8);
                listBox2.Items.Remove(ps.name9);
                listBox2.Items.Remove(ps.name10);
                listBox2.Items.Remove(ps.name11);
                listBox2.Items.Remove(ps.name12);
                listBox2.Items.Remove(ps.name13);
                listBox2.Items.Remove(ps.name14);
                listBox2.Items.Remove(ps.name15);
                listBox2.Items.Remove(ps.name16);
                listBox2.Items.Remove(ps.name17);
                listBox2.Items.Remove(ps.name18);
                listBox2.Items.Add(ps.name19);
                listBox2.Items.Add(ps.name20);
                listBox2.Items.Add(ps.name21);

            }
       
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}   
        
            
       
 

