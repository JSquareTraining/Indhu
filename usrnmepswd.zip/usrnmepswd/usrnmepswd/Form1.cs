﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace usrnmepswd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int count = 3;
        private void button1_Click(object sender, EventArgs e)
        {
            if (username.Text == "" && password.Text == "")
            {
                MessageBox.Show("Please enter the username and password", "error", MessageBoxButtons.OK);
            }
            else if (username.Text == "")
            {
                MessageBox.Show("Please enter the username", "error", MessageBoxButtons.OK);
            }
            else if (password.Text == "")
            {
                MessageBox.Show("Please enter the password", "error", MessageBoxButtons.OK);
            }
            else if (username.Text == "admin" && password.Text == "admin")
            {
                DialogResult odr = new DialogResult();
                odr = MessageBox.Show("You have successfully Logged in", "Success", MessageBoxButtons.OK);
                if (odr == DialogResult.OK)
                {
                    this.Close();
                }
                else
                {
                    this.Close();
                }
            }
            else
            {
                count--;
                DialogResult odr2 = new DialogResult();
                odr2 = MessageBox.Show("Please enter the Correct username/password", "Warning", MessageBoxButtons.OK);
                if (odr2 == DialogResult.OK)
                {
                    if (count > 0)
                    {
                        MessageBox.Show("You have" + count + "chances only", "Warning", MessageBoxButtons.OK);
                    }
                    else
                    {
                        this.Close();
                    }
                }

            }

        }
    }
}
