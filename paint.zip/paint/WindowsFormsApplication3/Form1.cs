﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
           // label4.BackColor = Color.Black;
            label2.BackColor = label4.BackColor;
            label3.BackColor = label4.BackColor;

        }

        private void label5_Click(object sender, EventArgs e)
        {
            //label5.BackColor = Color.White;
            label2.BackColor = label5.BackColor;
            label3.BackColor = label5.BackColor;

        }

        private void label6_Click(object sender, EventArgs e)
        {
           // label6.BackColor = Color.Violet;
            label2.BackColor = label6.BackColor;
            label3.BackColor = label6.BackColor;

        }

        private void label7_Click(object sender, EventArgs e)
        {
           // label7.BackColor = Color.Tomato;
            label2.BackColor = label7.BackColor;
            label3.BackColor = label7.BackColor;

        }

        private void label8_Click(object sender, EventArgs e)
        {
            //label8.BackColor = Color.Wheat;
            label2.BackColor = label8.BackColor;
            label3.BackColor = label8.BackColor;

        }

        private void label9_Click(object sender, EventArgs e)
        {
           // label9.BackColor = Color.YellowGreen;
            label2.BackColor = label9.BackColor;
            label3.BackColor = label9.BackColor;

        }

        private void label10_Click(object sender, EventArgs e)
        {
            //label10.BackColor = Color.Transparent;
            label2.BackColor = label10.BackColor;
            label3.BackColor = label10.BackColor;

        }

        private void label11_Click(object sender, EventArgs e)
        {
            //label11.BackColor = Color.SkyBlue;
            label2.BackColor = label11.BackColor;
            label3.BackColor = label11.BackColor;

        }
    }
}
