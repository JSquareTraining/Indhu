﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;        
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace WindowsFormsApplication13
{
    public partial class JV : Form
    {
        public JV()
        {
            InitializeComponent();
        }
        RES r = new RES();
        NET n = new NET();
        ST s = new ST();
      private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
      {
          
          if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
          {
              n.checkBox1.Checked = true;
              n.checkBox2.Checked = true;
              n.checkBox3.Checked = true;
              n.Show();
              this.Close();
          }
          if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
          {
              n.checkBox1.Checked = true;
              n.checkBox2.Checked = true;
              n.checkBox3.Checked = false;
              n.Show();
              this.Close();
          }
          if ((checkBox1.Checked == true) && (checkBox2.Checked == false) && (checkBox3.Checked == false))
          {
              r.checkBox16.Checked = true;
              r.checkBox17.Checked = false;
              r.checkBox18.Checked = false;
              r.Show();
              this.Close();
          }
          if ((checkBox1.Checked == true) && (checkBox2.Checked == false) && (checkBox3.Checked == true))
          {
              s.checkBox1.Checked = true;
              s.checkBox2.Checked = false;
              s.checkBox3.Checked = true;
              s.Show();
              this.Close();
          }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                r.checkBox1.Checked = true;
                n.checkBox4.Checked = true;
                s.checkBox9.Checked = true;
                n.checkBox9.Checked = true;
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

          
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked == true)
            {
                r.checkBox2.Checked = true;
                n.checkBox5.Checked = true;
                s.checkBox10.Checked = true;
                n.checkBox10.Checked = true;
            }
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton17.Checked == true)
            {
                r.checkBox5.Checked = true;
                n.checkBox8.Checked = true;
                s.checkBox13.Checked = true;
                n.checkBox13.Checked = true;
            }
        }
       
        private void JV_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.Silver;
            ResourceManager r = new ResourceManager("WindowsFormsApplication13.Properties.Resources",Assembly.GetExecutingAssembly());
            Properties.Settings obs = new Properties.Settings();
            if(obs.couple==1)
            {
                label1.Text = r.GetString("label1");
                radioButton1.Text = r.GetString("r1");
                radioButton2.Text = r.GetString("r2");
                radioButton3.Text = r.GetString("r3");
                radioButton4.Text = r.GetString("r4");
                label2.Text = r.GetString("label2");
                radioButton5.Text = r.GetString("r5");
                radioButton6.Text = r.GetString("r6");
                radioButton7.Text = r.GetString("r7");
                radioButton8.Text = r.GetString("r8");
                label3.Text = r.GetString("label3");
                radioButton9.Text = r.GetString("r9");
                radioButton10.Text = r.GetString("r10");
                radioButton11.Text = r.GetString("r11");
                radioButton12.Text = r.GetString("r12");
                label4.Text = r.GetString("label4");
                radioButton13.Text = r.GetString("r13");
                radioButton14.Text = r.GetString("r14");
                radioButton15.Text = r.GetString("r15");
                radioButton16.Text = r.GetString("r16");
                label5.Text = r.GetString("label5");
                radioButton17.Text = r.GetString("r17");
                radioButton18.Text = r.GetString("r18");
                radioButton19.Text = r.GetString("r19");
                radioButton20.Text = r.GetString("r20");
                this.WindowState = FormWindowState.Maximized;
                obs.couple=2;
                obs.Save();
            }
            else if (obs.couple==2)
            {
                label1.Text = r.GetString("label2");
                radioButton1.Text = r.GetString("r5");
                radioButton2.Text = r.GetString("r6");
                radioButton3.Text = r.GetString("r7");
                radioButton4.Text = r.GetString("r8");
                label2.Text = r.GetString("label3");
                radioButton5.Text = r.GetString("r9");
                radioButton6.Text = r.GetString("r10");
                radioButton7.Text = r.GetString("r11");
                radioButton8.Text = r.GetString("r12");
                label3.Text = r.GetString("label4");
                radioButton9.Text = r.GetString("r13");
                radioButton10.Text = r.GetString("r14");
                radioButton11.Text = r.GetString("r15");
                radioButton12.Text = r.GetString("r16");
                label4.Text = r.GetString("label5");
                radioButton13.Text = r.GetString("r17");
                radioButton14.Text = r.GetString("r18");
                radioButton15.Text = r.GetString("r19");
                radioButton16.Text = r.GetString("r20");
                label5.Text = r.GetString("label1");
                radioButton17.Text = r.GetString("r1");
                radioButton18.Text = r.GetString("r2");
                radioButton19.Text = r.GetString("r3");
                radioButton20.Text = r.GetString("r4");
                obs.couple = 3;
                obs.Save();
            }
            else if (obs.couple == 3)
            {
                label1.Text = r.GetString("label3");
                radioButton1.Text = r.GetString("r9");
                radioButton2.Text = r.GetString("r10");
                radioButton3.Text = r.GetString("r11");
                radioButton4.Text = r.GetString("r12");
                label2.Text = r.GetString("label4");
                radioButton5.Text = r.GetString("r13");
                radioButton6.Text = r.GetString("r14");
                radioButton7.Text = r.GetString("r15");
                radioButton8.Text = r.GetString("r16");
                label3.Text = r.GetString("label5");
                radioButton9.Text = r.GetString("r17");
                radioButton10.Text = r.GetString("r18");
                radioButton11.Text = r.GetString("r19");
                radioButton12.Text = r.GetString("r20");
                label4.Text = r.GetString("label1");
                radioButton13.Text = r.GetString("r1");
                radioButton14.Text = r.GetString("r2");
                radioButton15.Text = r.GetString("r3");
                radioButton16.Text = r.GetString("r4");
                label5.Text = r.GetString("label2");
                radioButton17.Text = r.GetString("r5");
                radioButton18.Text = r.GetString("r6");
                radioButton19.Text = r.GetString("r7");
                radioButton20.Text = r.GetString("r8");
                obs.couple = 4;
                obs.Save();
            }
            else if (obs.couple == 4)
            {
                label1.Text = r.GetString("label4");
                radioButton1.Text = r.GetString("r13");
                radioButton2.Text = r.GetString("r14");
                radioButton3.Text = r.GetString("r15");
                radioButton4.Text = r.GetString("r16");
                label2.Text = r.GetString("label5");
                radioButton5.Text = r.GetString("r17");
                radioButton6.Text = r.GetString("r18");
                radioButton7.Text = r.GetString("r19");
                radioButton8.Text = r.GetString("r20");
                label3.Text = r.GetString("label1");
                radioButton9.Text = r.GetString("r1");
                radioButton10.Text = r.GetString("r2");
                radioButton11.Text = r.GetString("r3");
                radioButton12.Text = r.GetString("r4");
                label4.Text = r.GetString("label2");
                radioButton13.Text = r.GetString("r5");
                radioButton14.Text = r.GetString("r6");
                radioButton15.Text = r.GetString("r7");
                radioButton16.Text = r.GetString("r8");
                label5.Text = r.GetString("label3");
                radioButton17.Text = r.GetString("r9");
                radioButton18.Text = r.GetString("r10");
                radioButton19.Text = r.GetString("r11");
                radioButton20.Text = r.GetString("r12");
                obs.couple = 5;
                obs.Save();
            }
            else if (obs.couple == 5)
            {
                label1.Text = r.GetString("label5");
                radioButton1.Text = r.GetString("r17");
                radioButton2.Text = r.GetString("r18");
                radioButton3.Text = r.GetString("r19");
                radioButton4.Text = r.GetString("r20");
                label2.Text = r.GetString("label4");
                radioButton5.Text = r.GetString("r13");
                radioButton6.Text = r.GetString("r14");
                radioButton7.Text = r.GetString("r15");
                radioButton8.Text = r.GetString("r16");
                label3.Text = r.GetString("label3");
                radioButton9.Text = r.GetString("r9");
                radioButton10.Text = r.GetString("r10");
                radioButton11.Text = r.GetString("r11");
                radioButton12.Text = r.GetString("r12");
                label4.Text = r.GetString("label2");
                radioButton13.Text = r.GetString("r5");
                radioButton14.Text = r.GetString("r6");
                radioButton15.Text = r.GetString("r7");
                radioButton16.Text = r.GetString("r8");
                label5.Text = r.GetString("label1");
                radioButton17.Text = r.GetString("r1");
                radioButton18.Text = r.GetString("r2");
                radioButton19.Text = r.GetString("r3");
                radioButton20.Text = r.GetString("r4");
                obs.couple = 1;
                obs.Save();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton9.Checked == true)
            {
                r.checkBox3.Checked = true;
                n.checkBox6.Checked = true;
                s.checkBox11.Checked = true;
                n.checkBox11.Checked = true;
            }
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton13.Checked == true)
            {
                r.checkBox4.Checked = true;
                n.checkBox7.Checked = true;
                s.checkBox12.Checked = true;
                n.checkBox12.Checked = true;
            }
        }
    }

}