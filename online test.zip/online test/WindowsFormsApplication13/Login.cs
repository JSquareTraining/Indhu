﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication13
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegForm f1 = new RegForm();
            f1.Show();


        }
        RES r = new RES();
        JV j = new JV();
        NET n = new NET();
        ST s = new ST();
        Properties.Settings ops = new Properties.Settings();
        private void button1_Click(object sender, EventArgs e)
        {

            if ((textBox1.Text == ops.uname) && (textBox2.Text == ops.passwrd))
            {
                MessageBox.Show("Welcome to On-Line Test");
                this.Close();
            }
            ops.Save();
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                j.checkBox1.Checked = true;
                j.checkBox2.Checked = true;
                j.checkBox3.Checked = true;
                j.Show();
            }
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                j.checkBox1.Checked = true;
                j.checkBox2.Checked = true;
                j.checkBox3.Checked = false;
                j.Show();
            }
            if ((checkBox1.Checked == true) && (checkBox2.Checked == false) && (checkBox3.Checked == false))
            {
                j.checkBox1.Checked = true;
                j.checkBox2.Checked = false;
                j.checkBox3.Checked = false;
                j.Show();


            }
            if ((checkBox1.Checked == true) && (checkBox2.Checked == false) && (checkBox3.Checked == true))
            {
                j.checkBox1.Checked = true;
                j.checkBox2.Checked = false;
                j.checkBox3.Checked = true;
                j.Show();
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                n.checkBox1.Checked = false;
                n.checkBox2.Checked = true;
                n.checkBox3.Checked = true;
                n.Show();
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == false) && (checkBox3.Checked == true))
            {
                s.checkBox1.Checked = false;
                s.checkBox2.Checked = false;
                s.checkBox3.Checked = true;
                s.Show();
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                n.checkBox1.Checked = false;
                n.checkBox2.Checked = true;
                n.checkBox3.Checked = false;
                n.Show();
            }


        }






        private void Login_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.Violet;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
                     
        }
    }
    }