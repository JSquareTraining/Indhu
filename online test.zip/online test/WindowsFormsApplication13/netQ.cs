﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace WindowsFormsApplication13
{
    public partial class NET : Form
    {
        public NET()
        {
            InitializeComponent();
        }
        RES r = new RES();
        ST s = new ST();
         private void NET_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.SkyBlue;
            this.WindowState = FormWindowState.Maximized;
            ResourceManager r1 = new ResourceManager("WindowsFormsApplication13.NET", Assembly.GetExecutingAssembly());
            ResourceManager r = new ResourceManager("WindowsFormsApplication13.Properties.Resources", Assembly.GetExecutingAssembly());
            Properties.Settings obs = new Properties.Settings();
            if (obs.couple==1)
            {
                label1.Text = r.GetString("label6");
                radioButton1.Text = r1.GetString("n1");
                radioButton2.Text = r1.GetString("n2");
                radioButton3.Text = r1.GetString("n3");
                radioButton4.Text = r1.GetString("n4");
                label2.Text = r.GetString("label7");
                radioButton5.Text = r1.GetString("n5");
                radioButton6.Text = r1.GetString("n6");
                radioButton7.Text = r1.GetString("n7");
                radioButton8.Text = r1.GetString("n8");
                label3.Text = r.GetString("label8");
                radioButton9.Text = r1.GetString("n9");
                radioButton10.Text = r1.GetString("n10");
                radioButton11.Text = r1.GetString("n11");
                radioButton12.Text = r1.GetString("n12");
                label4.Text = r.GetString("label9");
                radioButton13.Text = r1.GetString("n13");
                radioButton14.Text = r1.GetString("n14");
                radioButton15.Text = r1.GetString("n15");
                radioButton16.Text = r1.GetString("n16");
                label5.Text = r.GetString("label10");
                radioButton17.Text = r1.GetString("n17");
                radioButton18.Text = r1.GetString("n18");
                radioButton19.Text = r1.GetString("n19");
                radioButton20.Text = r1.GetString("n20");
                this.WindowState = FormWindowState.Maximized;
                obs.count = 2;     
                obs.Save();
            }
            else if (obs.couple==2)
            {
                label1.Text = r.GetString("label7");
                radioButton1.Text = r1.GetString("n5");
                radioButton2.Text = r1.GetString("n6");
                radioButton3.Text = r1.GetString("n7");
                radioButton4.Text = r1.GetString("n8");
                label2.Text = r.GetString("label8");
                radioButton5.Text = r1.GetString("n9");
                radioButton6.Text = r1.GetString("n10");
                radioButton7.Text = r1.GetString("n11");
                radioButton8.Text = r1.GetString("n12");
                label3.Text = r.GetString("label9");
                radioButton9.Text = r1.GetString("n13");
                radioButton10.Text = r1.GetString("n14");
                radioButton11.Text = r1.GetString("n15");
                radioButton12.Text = r1.GetString("n16");
                label4.Text = r.GetString("label10");
                radioButton13.Text = r1.GetString("n17");
                radioButton14.Text = r1.GetString("n18");
                radioButton15.Text = r1.GetString("n19");
                radioButton16.Text = r1.GetString("n20");
                label5.Text = r.GetString("label6");
                radioButton17.Text = r1.GetString("n1");
                radioButton18.Text = r1.GetString("n2");
                radioButton19.Text = r1.GetString("n3");
                radioButton20.Text = r1.GetString("n4");
                this.WindowState = FormWindowState.Maximized;
                obs.count = 3;
                obs.Save();
            }
            else if (obs.couple==3)
            {
                label1.Text = r.GetString("label8");
                radioButton1.Text = r1.GetString("n9");
                radioButton2.Text = r1.GetString("n10");
                radioButton3.Text = r1.GetString("n11");
                radioButton4.Text = r1.GetString("n12");
                label2.Text = r.GetString("label9");
                radioButton5.Text = r1.GetString("n13");
                radioButton6.Text = r1.GetString("n14");
                radioButton7.Text = r1.GetString("n15");
                radioButton8.Text = r1.GetString("n16");
                label3.Text = r.GetString("label10");
                radioButton9.Text = r1.GetString("n17");
                radioButton10.Text = r1.GetString("n18");
                radioButton11.Text = r1.GetString("n19");
                radioButton12.Text = r1.GetString("n20");
                label4.Text = r.GetString("label6");
                radioButton13.Text = r1.GetString("n1");
                radioButton14.Text = r1.GetString("n2");
                radioButton15.Text = r1.GetString("n3");
                radioButton16.Text = r1.GetString("n4");
                label5.Text = r.GetString("label7");
                radioButton17.Text = r1.GetString("n5");
                radioButton18.Text = r1.GetString("n6");
                radioButton19.Text = r1.GetString("n7");
                radioButton20.Text = r1.GetString("n8");
                this.WindowState = FormWindowState.Maximized;
                obs.count = 4;
                obs.Save();
            }
            else if (obs.couple==4)
            {
                label1.Text = r.GetString("label9");
                radioButton1.Text = r1.GetString("n13");
                radioButton2.Text = r1.GetString("n14");
                radioButton3.Text = r1.GetString("n15");
                radioButton4.Text = r1.GetString("n16");
                label2.Text = r.GetString("label10");
                radioButton5.Text = r1.GetString("n17");
                radioButton6.Text = r1.GetString("n18");
                radioButton7.Text = r1.GetString("n19");
                radioButton8.Text = r1.GetString("n20");
                label3.Text = r.GetString("label6");
                radioButton9.Text = r1.GetString("n1");
                radioButton10.Text = r1.GetString("n2");
                radioButton11.Text = r1.GetString("n3");
                radioButton12.Text = r1.GetString("n4");
                label4.Text = r.GetString("label7");
                radioButton13.Text = r1.GetString("n5");
                radioButton14.Text = r1.GetString("n6");
                radioButton15.Text = r1.GetString("n7");
                radioButton16.Text = r1.GetString("n8");
                label5.Text = r.GetString("label8");
                radioButton17.Text = r1.GetString("n9");
                radioButton18.Text = r1.GetString("n10");
                radioButton19.Text = r1.GetString("n11");
                radioButton20.Text = r1.GetString("n12");
                this.WindowState = FormWindowState.Maximized;
                obs.count = 5;
                obs.Save();
            }
            else if (obs.couple==5)
            {
                label1.Text = r.GetString("label10");
                radioButton1.Text = r1.GetString("n17");
                radioButton2.Text = r1.GetString("n18");
                radioButton3.Text = r1.GetString("n19");
                radioButton4.Text = r1.GetString("n20");
                label2.Text = r.GetString("label9");
                radioButton5.Text = r1.GetString("n13");
                radioButton6.Text = r1.GetString("n14");
                radioButton7.Text = r1.GetString("n15");
                radioButton8.Text = r1.GetString("n16");
                label3.Text = r.GetString("label8");
                radioButton9.Text = r1.GetString("n9");
                radioButton10.Text = r1.GetString("n10");
                radioButton11.Text = r1.GetString("n11");
                radioButton12.Text = r1.GetString("n12");
                label4.Text = r.GetString("label7");
                radioButton13.Text = r1.GetString("n5");
                radioButton14.Text = r1.GetString("n6");
                radioButton15.Text = r1.GetString("n7");
                radioButton16.Text = r1.GetString("n8");
                label5.Text = r.GetString("label6");
                radioButton17.Text = r1.GetString("n1");
                radioButton18.Text = r1.GetString("n2");
                radioButton19.Text = r1.GetString("n3");
                radioButton20.Text = r1.GetString("n4");
                this.WindowState = FormWindowState.Maximized;
                obs.count = 1;
                obs.Save();
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

           
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
          
        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton18.Checked == true)
            {
                r.checkBox10.Checked = true;
                s.checkBox8.Checked = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                s.checkBox1.Checked = true;
                s.checkBox2.Checked = true;
                s.checkBox3.Checked = true;
                s.Show();
                this.Close();
            }
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                r.checkBox16.Checked = true;
                r.checkBox17.Checked = true;
                r.checkBox18.Checked = false;
                r.Show();
                this.Close();
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                s.checkBox1.Checked = false;
                s.checkBox2.Checked = true;
                s.checkBox3.Checked = true;
                s.Show();
                this.Close();
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                r.checkBox16.Checked = false;
                r.checkBox17.Checked = true;
                r.checkBox18.Checked = false; 
                r.Show();
                this.Close();
            }       
        }

        private void button2_Click(object sender, EventArgs e)
        {
         
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked == true)
            {
                r.checkBox5.Checked = true;
                s.checkBox18.Checked = true;
                
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == true)
            {
                r.checkBox4.Checked = true;
                s.checkBox17.Checked = true;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                r.checkBox3.Checked = true;
                s.checkBox16.Checked = true;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                r.checkBox2.Checked = true;
                s.checkBox15.Checked = true;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                r.checkBox1.Checked = true;
                s.checkBox14.Checked = true;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

           
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {

                r.checkBox6.Checked = true;
                s.checkBox4.Checked = true;
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked == true)
            {

                r.checkBox7.Checked = true;
                s.checkBox5.Checked = true;
            }
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton10.Checked == true)
            {
                r.checkBox8.Checked = true;
                s.checkBox6.Checked = true;
            }
        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton14.Checked == true)
            {
                r.checkBox9.Checked = true;
                s.checkBox7.Checked = true;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                s.checkBox19.Checked = true;
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox10.Checked == true)
            {
                s.checkBox20.Checked = true;
            }
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox12.Checked == true)
            {
                s.checkBox22.Checked = true;
            }
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox13.Checked == true)
            {
                s.checkBox23.Checked = true;
            }
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox11.Checked == true)
            {
                s.checkBox21.Checked = true;
            }
        }
    }
}
