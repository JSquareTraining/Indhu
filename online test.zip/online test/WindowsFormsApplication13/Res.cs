﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication13
{
    public partial class RES : Form
    {
        public RES()
        {
            InitializeComponent();
        }
        
       
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {

        }
    
        private void button1_Click(object sender, EventArgs e)
        { Properties.Settings ops=new Properties.Settings();
        textBox1.Text = ops.uname;
        textBox2.Text = ops.wel;
            if ((checkBox16.Checked == true) && (checkBox17.Checked == true) && (checkBox18.Checked == true))
            {
                panel1.Visible = true;
                panel2.Visible = true;
                panel3.Visible = true;
            }
            if ((checkBox16.Checked == true) && (checkBox17.Checked == true) && (checkBox18.Checked == false))
            {
               panel1.Visible = true;
               panel2.Visible = true;
              
                
            }
            if ((checkBox16.Checked == true) && (checkBox17.Checked == false) && (checkBox18.Checked == false))
            {
                panel1.Visible = true;
                
            }
            if ((checkBox16.Checked == true) && (checkBox17.Checked == false) && (checkBox18.Checked == true))
            {
                panel1.Visible = true;
                panel3.Visible = true;
            }
            if ((checkBox16.Checked == false) && (checkBox17.Checked == true) && (checkBox18.Checked == true))
            {
                
                panel3.Visible = true;
                panel2.Visible = true;
                
                
            }
            if ((checkBox16.Checked == false) && (checkBox17.Checked == false) && (checkBox18.Checked == true))
            {
                panel3.Visible = true;
            }
            if ((checkBox16.Checked == false) && (checkBox17.Checked == true) && (checkBox18.Checked == false))
            {
                panel2.Visible = true;
            }
            }

        private void RES_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.Tomato;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //textBox3.Text = "Hai!!!";
        }
    }
}
