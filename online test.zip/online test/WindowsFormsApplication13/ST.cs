﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace WindowsFormsApplication13
{
    public partial class ST : Form
    {
        public ST()
        {
            InitializeComponent();
        }
        RES r = new RES();
       
       
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton7.Checked == true)
            {
                r.checkBox12.Checked = true;
            }
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                r.checkBox16.Checked = true;
                r.checkBox17.Checked = true;
                r.checkBox18.Checked = true;
                r.Show();
                this.Close();
            }
            if ((checkBox1.Checked == true) && (checkBox2.Checked == false) && (checkBox3.Checked == true))
            {
                r.checkBox16.Checked = true;
                r.checkBox17.Checked = false;
                r.checkBox18.Checked = true;
                r.Show();
                this.Close();
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                r.checkBox16.Checked = false;
                r.checkBox17.Checked = true;
                r.checkBox18.Checked = true;
                r.Show();
                this.Close();
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == false) && (checkBox3.Checked == true))
            {
                r.checkBox16.Checked = false;
                r.checkBox17.Checked = false;
                r.checkBox18.Checked = true;
                r.Show();
                this.Close();
            }
        }

        private void ST_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.Silver;
            this.WindowState = FormWindowState.Maximized;
            ResourceManager r = new ResourceManager("WindowsFormsApplication13.Properties.Resources", Assembly.GetExecutingAssembly());
            ResourceManager r1 = new ResourceManager("WindowsFormsApplication13.ST", Assembly.GetExecutingAssembly());
            Properties.Settings obs = new Properties.Settings();
            if (obs.couple == 1)
            {
                label1.Text = r.GetString("label11");
                radioButton1.Text = r1.GetString("s1");
                radioButton2.Text = r1.GetString("s2");
                radioButton3.Text = r1.GetString("s3");
                radioButton4.Text = r1.GetString("s4");
                label2.Text = r.GetString("label12");
                radioButton5.Text = r1.GetString("s5");
                radioButton6.Text = r1.GetString("s6");
                radioButton7.Text = r1.GetString("s7");
                radioButton8.Text = r1.GetString("s8");
                label3.Text = r.GetString("label13");
                radioButton9.Text = r1.GetString("s9");
                radioButton10.Text = r1.GetString("s10");
                radioButton11.Text = r1.GetString("s11");
                radioButton12.Text = r1.GetString("s12");
                label4.Text = r.GetString("label14");
                radioButton13.Text = r1.GetString("s13");
                radioButton14.Text = r1.GetString("s14");
                radioButton15.Text = r1.GetString("s15");
                radioButton16.Text = r1.GetString("s16");
                label5.Text = r.GetString("label15");
                radioButton17.Text = r1.GetString("s17");
                radioButton18.Text = r1.GetString("s18");
                radioButton19.Text = r1.GetString("s19");
                radioButton20.Text = r1.GetString("s20");
                this.WindowState = FormWindowState.Maximized;
                obs.couple = 2;
                obs.Save();
            }
            else if (obs.couple == 2)
            {
                label1.Text = r.GetString("label12");
                radioButton1.Text = r1.GetString("s5");
                radioButton2.Text = r1.GetString("s6");
                radioButton3.Text = r1.GetString("s7");
                radioButton4.Text = r1.GetString("s8");
                label2.Text = r.GetString("label13");
                radioButton5.Text = r1.GetString("s9");
                radioButton6.Text = r1.GetString("s10");
                radioButton7.Text = r1.GetString("s11");
                radioButton8.Text = r1.GetString("s12");
                label3.Text = r.GetString("label14");
                radioButton9.Text = r1.GetString("s13");
                radioButton10.Text = r1.GetString("r14");
                radioButton11.Text = r1.GetString("r15");
                radioButton12.Text = r1.GetString("r16");
                label4.Text = r.GetString("label15");
                radioButton13.Text = r1.GetString("s17");
                radioButton14.Text = r1.GetString("s18");
                radioButton15.Text = r1.GetString("s19");
                radioButton16.Text = r1.GetString("s20");
                label5.Text = r.GetString("label11");
                radioButton17.Text = r1.GetString("s1");
                radioButton18.Text = r1.GetString("s2");
                radioButton19.Text = r1.GetString("s3");
                radioButton20.Text = r1.GetString("s4");
                obs.couple = 3;
                obs.Save();
            }
            else if (obs.couple == 3)
            {
                label1.Text = r.GetString("label13");
                radioButton1.Text = r1.GetString("s9");
                radioButton2.Text = r1.GetString("s10");
                radioButton3.Text = r1.GetString("s11");
                radioButton4.Text = r1.GetString("s12");
                label2.Text = r.GetString("label14");
                radioButton5.Text = r1.GetString("s13");
                radioButton6.Text = r1.GetString("s14");
                radioButton7.Text = r1.GetString("s15");
                radioButton8.Text = r1.GetString("s16");
                label3.Text = r.GetString("label15");
                radioButton9.Text = r1.GetString("s17");
                radioButton10.Text = r1.GetString("s18");
                radioButton11.Text = r1.GetString("s19");
                radioButton12.Text = r1.GetString("s20");
                label4.Text = r.GetString("label11");
                radioButton13.Text = r1.GetString("s1");
                radioButton14.Text = r1.GetString("s2");
                radioButton15.Text = r1.GetString("s3");
                radioButton16.Text = r1.GetString("s4");
                label5.Text = r.GetString("label12");
                radioButton17.Text = r1.GetString("s5");
                radioButton18.Text = r1.GetString("s6");
                radioButton19.Text = r1.GetString("s7");
                radioButton20.Text = r1.GetString("s8");
                obs.couple = 4;
                obs.Save();
            }
            else if (obs.couple == 4)
            {
                label1.Text = r.GetString("label14");
                radioButton1.Text = r1.GetString("s13");
                radioButton2.Text = r1.GetString("s14");
                radioButton3.Text = r1.GetString("s15");
                radioButton4.Text = r1.GetString("s16");
                label2.Text = r.GetString("label15");
                radioButton5.Text = r1.GetString("s17");
                radioButton6.Text = r1.GetString("s18");
                radioButton7.Text = r1.GetString("s19");
                radioButton8.Text = r1.GetString("s20");
                label3.Text = r.GetString("label11");
                radioButton9.Text = r1.GetString("s1");
                radioButton10.Text = r1.GetString("s2");
                radioButton11.Text = r1.GetString("s3");
                radioButton12.Text = r1.GetString("s4");
                label4.Text = r.GetString("label12");
                radioButton13.Text = r1.GetString("s5");
                radioButton14.Text = r1.GetString("s6");
                radioButton15.Text = r1.GetString("s7");
                radioButton16.Text = r1.GetString("s8");
                label5.Text = r.GetString("label13");
                radioButton17.Text = r1.GetString("s9");
                radioButton18.Text = r1.GetString("s10");
                radioButton19.Text = r1.GetString("s11");
                radioButton20.Text = r1.GetString("s12");
                obs.couple = 5;
                obs.Save();
            }
            else if (obs.couple == 5)
            {
                label1.Text = r.GetString("label15");
                radioButton1.Text = r1.GetString("s17");
                radioButton2.Text = r1.GetString("s18");
                radioButton3.Text = r1.GetString("s19");
                radioButton4.Text = r1.GetString("s20");
                label2.Text = r.GetString("label14");
                radioButton5.Text = r1.GetString("s13");
                radioButton6.Text = r1.GetString("s14");
                radioButton7.Text = r1.GetString("s15");
                radioButton8.Text = r1.GetString("s16");
                label3.Text = r.GetString("label13");
                radioButton9.Text = r1.GetString("s9");
                radioButton10.Text = r1.GetString("s10");
                radioButton11.Text = r1.GetString("s11");
                radioButton12.Text = r1.GetString("s12");
                label4.Text = r.GetString("label12");
                radioButton13.Text = r1.GetString("s5");
                radioButton14.Text = r1.GetString("s6");
                radioButton15.Text = r1.GetString("s7");
                radioButton16.Text = r1.GetString("s8");
                label5.Text = r.GetString("label11");
                radioButton17.Text = r1.GetString("s1");
                radioButton18.Text = r1.GetString("s2");
                radioButton19.Text = r1.GetString("s3");
                radioButton20.Text = r1.GetString("s4");
                obs.couple = 1;
                obs.Save();
            }
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            r.checkBox10.Checked = true;
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            r.checkBox9.Checked = true;
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            r.checkBox8.Checked = true;
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            r.checkBox7.Checked = true;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            r.checkBox6.Checked = true;
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                r.checkBox5.Checked = true;
            }
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                r.checkBox4.Checked = true;
            }
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                r.checkBox3.Checked = true;
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                r.checkBox2.Checked = true;
            }
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                r.checkBox1.Checked = true;
            }
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox18.Checked == true)
            {
                r.checkBox1.Checked = true;
            }
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox17.Checked == true)
            {
                r.checkBox1.Checked = true;
            }
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox16.Checked == true)
            {
                r.checkBox1.Checked = true;
            }
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox15.Checked == true)
            {
                r.checkBox1.Checked = true;
            }
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox14.Checked == true)
            {
                r.checkBox1.Checked = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                r.checkBox11.Checked = true;
            }
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {

            if (radioButton11.Checked == true)
            {
                r.checkBox13.Checked = true;
            }
        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton15.Checked == true)
            {
                r.checkBox14.Checked = true;
            }
        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton19.Checked == true)
            {
                r.checkBox15.Checked = true;
            }
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox19.Checked == true)
            {
                r.checkBox1.Checked = true;
            }
        }

        private void checkBox23_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox23.Checked == true)
            {
                r.checkBox5.Checked = true;
            }
        }

        private void checkBox22_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox22.Checked == true)
            {
                r.checkBox4.Checked = true;
            }
        }

        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox21.Checked == true)
            {
                r.checkBox3.Checked = true;
            }
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox20.Checked == true)
            {
                r.checkBox2.Checked = true;
            }
        }
    }
}
