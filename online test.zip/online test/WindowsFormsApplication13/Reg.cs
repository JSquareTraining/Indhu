﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication13
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
           
        }
        Login f2 = new Login();
        
        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.Thistle;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            Properties.Settings ops = new Properties.Settings();
            ops.uname = textBox2.Text;
            ops.passwrd = textBox3.Text; ops.Save();
            f2.textBox1.Text = textBox2.Text;
            f2.textBox2.Text = textBox3.Text;
            if ((textBox1.Text == "") && (textBox2.Text == ""))
            {
                MessageBox.Show("Fill  mandatory fields");
            }
            else if ((checkBox1.Checked == false) && (checkBox2.Checked == false) && (checkBox3.Checked == false))
            {
                MessageBox.Show("Select Atleast One Subject");
            }

            else if (checkBox4.Checked == true)
            {
                MessageBox.Show("Registered Successfully");

                
            }
           
            
        }

        
        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            
        }
        
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void checkBox_Checkchanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (checkBox1.Checked == true)
            {
                f2.checkBox1.Checked = true; f2.Show(); this.Close();
            }
           
            if (checkBox2.Checked == true)
            {
                f2.checkBox2.Checked = true; f2.Show(); this.Close();
            }
            
            if (checkBox3.Checked == true)
            {
                f2.checkBox3.Checked = true; f2.Show(); this.Close();
            }
          
        }
       
    }
}
